#include <jni.h>

int main() {
    return 0;
}
